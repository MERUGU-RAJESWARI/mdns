import vscode, { CancellationTokenSource } from "vscode";
import CryptoJS from "crypto-js";
import Bonjour, { Service } from "bonjour";

// Initialize Bonjour service
const bonjour = Bonjour();

import { serviceName, discoveryTimeout } from "./const";

type Item = {
  label: string;
  service: Service;
};

interface ServiceTxt {
    p: string; // or whatever type it should be
    l: string; // or whatever type it should be
    // Add other properties as needed
}

async function find(token: vscode.CancellationToken): Promise<Item[]> {
  const services: Item[] = [];
  const browser = bonjour.find({ type: serviceName }, function (service) {
    services.push({
      label: service.name,
      service
    });
  });

  await vscode.window.withProgress(
    {
      location: vscode.ProgressLocation.Notification,
      title: "Discovering services...",
      cancellable: true
    },
    (progress, cancellationToken) => {
      const step = 100 / discoveryTimeout;
      const nobodyMsg = "No services found 😢";
      progress.report({
        increment: 0,
        message: nobodyMsg
      });

      return new Promise<void>((resolve) => {
        let elapsed = 0;
        const interval = setInterval(() => {
          elapsed++;
          const names = services.map((s) => s.label).join(", ");
          const message = names || nobodyMsg;
          progress.report({
            increment: step,
            message: message
          });

          if (elapsed === discoveryTimeout) {
            clearInterval(interval);
            resolve();
          }
        }, 1000);

        cancellationToken.onCancellationRequested(() => {
          clearInterval(interval);
          resolve();
        });
      });
    }
  );

  browser.stop();
  return services;
}

export default async function () {
  const tokenSrc = new CancellationTokenSource();
  const services = await find(tokenSrc.token);

  if (services.length === 0) {
    vscode.window.showErrorMessage("No peers found.");
    return;
  }

  const selected = await vscode.window.showQuickPick<Item>(services);
  if (!selected) {
    return;
  }

  const askPassword = async (): Promise<string | undefined> => {
    const password = await vscode.window.showInputBox({
      ignoreFocusOut: true,
      password: true,
      placeHolder: "Please enter the session password"
    });
    if (!password) {
      return;
    }

    const hashedPassword = (selected.service.txt as ServiceTxt)["p"];
    const match = CryptoJS.SHA256(password).toString() === hashedPassword;
    if (!match) {
      vscode.window.showErrorMessage("Incorrect password, please try again.");
      return await askPassword();
    }
    return password;
  };

  const password = await askPassword();
  if (!password) {
    return;
  }

  const encryptedCode = (selected.service.txt as ServiceTxt)["l"];
  const code = CryptoJS.AES.decrypt(encryptedCode, password).toString(
    CryptoJS.enc.Utf8
  );
  const link = `https://lms.edubottechnologies.com/join?${code}`;
  vscode.commands.executeCommand("liveshare.openLink", link);
}
