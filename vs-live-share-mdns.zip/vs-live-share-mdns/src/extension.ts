import vscode from "vscode";
import startPublish from "./publish";
import discoverCmd from "./discover";
import { extNamespace } from "./const";

interface CommandMap {
    publish: () => Promise<void>;
    discover: () => Promise<void>;
    [key: string]: () => Promise<void>; // Allow any string key
}

const commands: CommandMap = {
    publish: async () => { /* implementation */ },
    discover: async () => { /* implementation */ },
};

export function activate(context: vscode.ExtensionContext) {
  for (let command in commands) {
    const callback = commands[command];
    command = `${extNamespace}.${command}`;
    const disposable = vscode.commands.registerCommand(command, callback);
    context.subscriptions.push(disposable);
  }
}

// this method is called when your extension is deactivated
export function deactivate() { }
